make clean
make
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/D-1.cmm output/D-1.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/A-1.cmm output/A-1.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/B-1.cmm output/B-1.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/E1-1.cmm output/E1-1.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/E2-1.cmm output/E2-1.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/C-1.cmm output/C-1.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/A-2.cmm output/A-2.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/B-2.cmm output/B-2.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/E1-2.cmm output/E1-2.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/E2-2.cmm output/E2-2.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/C-2.cmm output/C-2.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/A-3.cmm output/A-3.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/B-3.cmm output/B-3.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/E1-3.cmm output/E1-3.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/E2-3.cmm output/E2-3.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/A-4.cmm output/A-4.s
./parser ../../Tests_3_Normal/Tests\ \(normal\)/tests/A-5.cmm output/A-5.s
rm output.zip
zip output.zip output/*
