#include "IR.h"

void initMipGen();
void MipGen(const char* dstFilePath);
