#include"mipGen.h"

void initMipGen(){

    return;
}

void MipGen(const char* dstFilePath){

    return;
}