#include "semanteme.h"
//#define SEM_DEBUG

bool semanticFlag = true;

unsigned hash_pjw(char* name){
    unsigned val = 0, i;
    for (; *name; ++name) {
        val = (val << 2) + *name;
        if (i = val & ~HASHSIZE)
            val = (val ^ (i >> 12)) & HASHSIZE;
    }
    return val;
}

void hash_add(HashTable* a){
    unsigned index = hash_pjw(a->name);
    a->next = hashTable[index];
    hashTable[index] = a;
    #ifdef SEM_DEBUG
    printf("hash_table: '\"%s\" added to table\n", a->name);
    #endif
    return;
}

HashTable* hash_find(char* name){
    unsigned index = hash_pjw(name);
    #ifdef SEM_DEBUG
        printf("hash_table: finding \"%s\"\n", name);
        printf("index = %d\n", index);
        printf("hashtable = %d\n", hashTable[index] == NULL);
    #endif
    if(hashTable[index] != NULL){
        for(HashTable* p = hashTable[index]; p != NULL; p = p->next){
            if(!strcmp(p->name, name)){
                #ifdef SEM_DEBUG
                    printType(p->type, 0);
                #endif
                return p;
            }
        }
    }
    return NULL;
}

void serror(int typeNo, int lineNo, const char* err){
    printf("Error type %d at line %d: %s.\n", typeNo, lineNo, err);
    semanticFlag = false;
    return;
}

void initTable(){
    //memset(hashTable, Null, sizeof(int) * (HASHSIZE+1));
   for(int i = 0; i <= HASHSIZE ; i++)
    hashTable[i] = NULL;
    return;
}

void smtm_Program(Node* node){
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Program...\n");
        #endif
        smtm_ExtDefList(node->child);
    }
    return;
}

void smtm_ExtDefList(Node* node){
    //ExtDefList -> null
    if(node->smtmType == 1)
        ;
    //ExtDefList -> ExtDef ExtDefList
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_ExtDefList 2...\n");
        #endif
        smtm_ExtDef(node->child);
        smtm_ExtDefList(node->child->next);
    };
}


void smtm_ExtDef(Node *node){
    FieldList* extdef = (FieldList*)malloc(sizeof(FieldList));
    extdef->type = (sType*)malloc(sizeof(sType));
    extdef->tail = NULL;
    //ExtDef -> Specifier ExtDecList SEMI
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_ExtDef 1...\n");
        #endif
        
        node->child->inh = extdef;
        smtm_Specifier(node->child);
        node->child->next->inh = node->child->syn;
        smtm_ExtDecList(node->child->next);
        
    }
    //ExtDef -> Specifier SEMI
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_ExtDef 2...\n");
        #endif
        
        node->child->inh = extdef;
        
        smtm_Specifier(node->child);
    }
    //ExtDef -> Specifier FunDec CompSt
    else if(node->smtmType == 3){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_ExtDef 3...\n");
        #endif
        
        extdef->type->kind = sFUNCTION;
        node->child->inh = extdef;
        node->child->next->inh = extdef;
        
        smtm_Specifier(node->child);
        //set return val type of func
        
        if(node->child->syn->type->kind == sSTRUCTURE){
            sType* tType = (sType*)malloc(sizeof(sType));
            tType->kind = sSTRUCTVAR;
            tType->u.structVar = node->child->syn->type->u.structure;
            node->child->inh->type->u.function.type = tType;
        }
        else {
            node->child->inh->type->u.function.type = node->child->syn->type;
        }
        node->child->inh->type->u.function.argList = NULL;
        node->child->inh->type->u.function.argc = 0;
        
        smtm_FunDec(node->child->next);
        
        node->child->next->next->inh = node->child->syn;
        
        smtm_CompSt(node->child->next->next);
        
    }
    return;
}


void smtm_Specifier(Node *node){
    
    FieldList* syn = (FieldList*)malloc(sizeof(FieldList));
    syn->type = (sType*)malloc(sizeof(sType));
    syn->tail = NULL;
    
    //Specifier -> TYPE
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Specifier 1...\n");
        #endif
        
        if(!strcmp("int", node->child->val.strVal))
            syn->type->kind = sINT;
        else if(!strcmp("float", node->child->val.strVal))
            syn->type->kind = sFLOAT;
        node->syn = syn;
        #ifdef SEM_DEBUG
            printf("Specifier: type is %d\n", node->syn->type->kind);
        #endif

        
    }

    //Specifier ->StructSpecifier
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Specifier 2...\n");
        #endif
        
        syn->type->kind = sSTRUCTURE;
        syn->type->u.structure = NULL;
        node->child->inh = syn;
        
        smtm_StructSpecifier(node->child);
        node->syn = node->child->syn;

    }
    return ;
}
void smtm_ExtDecList(Node *node){
    //printf("smtm_ExtDecList not finished\n");
    //ExtDecList -> VarDec...
    if(node->inh->type->kind == sSTRUCTVAR && node->inh->type->u.structure == NULL){
        char s[512];
        sprintf(s, "Undefined structure \"%s\"", node->inh->name);
        serror(17, node->lineNum, s);
        return;
    }
    node->child->inh = node->inh;
    smtm_VarDec(node->child);
    node->syn = node->child->syn;
    //ExtDecList -> VarDec
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_ExtDecList 1...\n");
        #endif
        ;
    }
    //ExtDecList -> VarDec COMMA ExtDecList
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_ExtDecList 1...\n");
        #endif
        node->child->next->next->inh = node->inh;
        smtm_ExtDecList(node->child->next->next);
        FieldList *p = node->syn;
        while(p->tail) p = p->tail;
        p->tail = node->child->next->next->syn;
    }
    return ;
}
void smtm_FunDec(Node *node){
    //FunDec -> ID ...
    HashTable* func = hash_find(node->child->val.strVal);
    if(func){
        char s[512];
        sprintf(s, "duplicate function definition \"%s\"", node->child->val.strVal);
        serror(4, node->lineNum, s);
        node->inh->type->kind = sWRONGFUNC;
    }
    else {
        HashTable* func = (HashTable*)malloc(sizeof(HashTable));
        func->name = node->child->val.strVal;
        func->next = NULL;
        func->size = 0;
        func->type = node->inh->type;
        hash_add(func);
    }
    if(node->smtmType == 1){
        //FunDec -> ID LP VarList RP
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_FunDec 1...\n");
        #endif        
        //HashTable* func = hash_find(node->child->val.strVal);
        node->child->next->next->inh = node->inh;
        smtm_VarList(node->child->next->next);
        node->inh->type->u.function.argList = node->child->next->next->syn;
    }
    //FunDec -> ID LP RP
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_FunDec 2...\n");
        #endif
        //HashTable* func = hash_find(node->child->val.strVal);
        node->inh->type->u.function.argList = NULL;
    }
    return ;
}
/*
void smtm_VarList(Node *node){
    //VarList -> ParamDec COMMA VarList
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_VarList1...\n");
        #endif
        smtm_ParamDec(node->child);
        if(node->child->syn) node->inh->type->u.function.argc++;
        else {node->inh->type->kind = sWRONGFUNC; return;}
        node->syn = node->child->syn;
        node->child->next->next->inh = node->inh;
        smtm_VarList(node->child->next->next);
        FieldList* p = node->syn;
        while(p->tail) p = p->tail;
        p->tail = node->child->next->next->syn;
    }
    //VarList -> ParamDec
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_VarList2...\n");
        #endif
        smtm_ParamDec(node->child);
        if(node->child->syn) node->inh->type->u.function.argc++;
        else {node->inh->type->kind = sWRONGFUNC; return;}
        node->syn = node->child->syn;
    }
    return ;
}*/
void smtm_VarList(Node* node)
{
    // printf("VarList\n");
    smtm_ParamDec(node->child);
    if (node->child->syn)
        node->inh->type->u.function.argc++;
    else {
        node->inh->type->kind = sWRONGFUNC;
        return;
    }
    node->syn = node->child->syn;
    switch (node->smtmType) {
    case 1: // ParamDec COMMA VarList
    {
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_VarList1...\n");
        #endif
        childAt(node, 2)->inh = node->inh;
        smtm_VarList(childAt(node, 2));
        FieldList* p = node->syn;
        while (p->tail) {
            p = p->tail;
        }
        p->tail = childAt(node, 2)->syn;
    } break;
    case 2: // ParamDec
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_VarList2...\n");
        #endif
        break;
    default:
        break;
    }
}
/*
void smtm_ParamDec(Node *node){
    //ParamDec -> Specifier VarDec
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_ParamDec1...\n");
        #endif
        smtm_Specifier(node->child);
        node->child->next->inh = node->child->syn;
        smtm_VarDec(node->child->next);
        //node->syn = node->child->next->syn;

        if(node->child->next->syn){
            node->syn = (FieldList*)malloc(sizeof(FieldList));
            node->syn->name = node->child->next->syn->name;
            node->syn->type = node->child->next->syn->type;
            node->syn->tail = NULL;
        }
        else node->syn = NULL;
    }
    return ;
}*/
void smtm_ParamDec(Node* node)
{
    //printf("ParamDec%d\n", node->smtmType);
    smtm_Specifier(node->child);
    childAt(node, 1)->inh = node->child->syn;
    smtm_VarDec(childAt(node, 1));
    node->syn = childAt(node, 1)->syn;
    if (childAt(node, 1)->syn) {
        node->syn = (FieldList*)malloc(sizeof(FieldList));
        node->syn->name = childAt(node, 1)->syn->name;
        node->syn->type = childAt(node, 1)->syn->type;
        node->syn->tail = NULL;
    } else {
        node->syn = NULL;
    }
}


void smtm_CompSt(Node *node){
    //CompSt ->LC DefList StmtList RC
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_CompSt1...\n");
        #endif
        /*
        node->child->next->inh = node->inh;
        node->child->next->next->inh = node->inh;
        smtm_DefList(node->child->next);
        smtm_StmtList(node->child->next->next);*/

        childAt(node, 1)->inh = node->inh;
        childAt(node, 2)->inh = node->inh;
        smtm_DefList(childAt(node, 1));
        smtm_StmtList(childAt(node, 2));
    }
    return ;
}
/*
void smtm_StmtList(Node *node){
    //StmtList -> Stmt StmtList
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_StmtList1...\n");
        #endif
        node->child->inh = node->inh;
        node->child->next->inh = node->inh;
        smtm_Stmt(node->child);
        smtm_StmtList(node->child->next);
    }
    //StmtList -> null
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_StmtList2...\n");
        #endif
        ;
    }
    return ;
}
*/

void smtm_StmtList(Node* node)
{
    //printf("StmtList1...\n");
    if (node->smtmType == 1) {
        node->child->inh = node->inh;
        childAt(node, 1)->inh = node->inh;
        smtm_Stmt(node->child);
        smtm_StmtList(childAt(node, 1));
    }
}


/*
void smtm_Stmt(Node *node){
    //Stmt -> Exp SEMI
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Stmt1...\n");
        #endif
        smtm_Exp(node->child);
    }
    //Stmt -> CompSt
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Stmt2...\n");
        #endif
        node->child->inh = node->inh;
        smtm_CompSt(node->child);
    }
    //Stmt -> RETURN Exp SEMI
    else if(node->smtmType == 3){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Stmt3...\n");
        #endif
        smtm_Exp(node->child->next);
        if(node->child->next->syn && node->inh->type->kind != node->child->next->syn->type->kind)
            if(node->inh->type->kind == sSTRUCTURE && node->child->next->syn->type->kind == sSTRUCTVAR 
                && structFieldCmp(node->inh->type->u.structure, node->child->next->syn->type->u.structVar))
                {;}
            else serror(8, node->child->next->lineNum, " Type mismatched for return");
    }
    //Stmt -> IF LP Exp RP Stmt
    else if(node->smtmType == 4){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Stmt4...\n");
        #endif
        node->child->next->next->next->next->inh = node->inh;
        smtm_Exp(node->child->next->next);
        if(node->child->next->next->syn && node->child->next->next->syn->type->kind != sINT)
            serror(7, node->child->next->next->lineNum, "Type mismatched for operands");
        smtm_Stmt(node->child->next->next->next->next);
    }
    //Stmt -> IF LP Exp RP Stmt ELSE Stmt
    else if(node->smtmType == 5){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Stmt5...\n");
        #endif
        node->child->next->next->next->next->inh = node->child->next->next->next->next->next->next->inh = node->inh;
        smtm_Exp(node->child->next->next);
        if(node->child->next->next->syn && node->child->next->next->syn->type->kind != sINT)
            serror(7, node->child->next->next->lineNum, "Type mismatched for operands");
        smtm_Stmt(node->child->next->next->next->next);
        smtm_Stmt(node->child->next->next->next->next->next->next);
    }
    //Stmt -> WHILE LP Exp RP Stmt
    else if(node->smtmType == 6){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Stmt6...\n");
        #endif
        node->child->next->next->next->next->inh = node->inh;
        smtm_Exp(node->child->next->next);
        if(node->child->next->next->syn && node->child->next->next->syn->type->kind != sINT)
            serror(7, node->child->next->next->lineNum, "Type mismatched for operands");
        smtm_Stmt(node->child->next->next->next->next);
        }
    return ;
}
*/

void smtm_Stmt(Node* node)
{
    //printf("Stmt%d...\n", node->smtmType);
    switch (node->smtmType) {
    case 1: // Exp SEMI
        smtm_Exp(node->child);
        break;
    case 2: // CompSt
        node->child->inh = node->inh;
        smtm_CompSt(node->child);
        break;
    case 3: // RETURN Exp SEMI
        smtm_Exp(childAt(node, 1));
        if (childAt(node, 1)->syn) {
            if (node->inh->type->kind != childAt(node, 1)->syn->type->kind) {
                if (node->inh->type->kind == sSTRUCTURE && childAt(node, 1)->syn->type->kind == sSTRUCTVAR) {
                    int res = structFieldCmp(node->inh->type->u.structure, childAt(node, 1)->syn->type->u.structVar);
                    if (res)
                        break;
                }
                serror(8, childAt(node, 1)->lineNum, "Type mismatched for return");
            }
        }
        break;
    case 4: // IF LP Exp RP Stmt
        childAt(node, 4)->inh = node->inh;
        smtm_Exp(childAt(node, 2));
        if (childAt(node, 2)->syn) {
            if (childAt(node, 2)->syn->type->kind != sINT) {
                serror(7, childAt(node, 2)->lineNum, "Type mismatched for operands");
            }
        }
        smtm_Stmt(childAt(node, 4));
        break;
    case 5: // IF LP Exp RP Stmt ELSE Stmt
        childAt(node, 4)->inh = node->inh;
        childAt(node, 6)->inh = node->inh;
        smtm_Exp(childAt(node, 2));
        if (childAt(node, 2)->syn) {
            if (childAt(node, 2)->syn->type->kind != sINT) {
                serror(7, childAt(node, 2)->lineNum, "Type mismatched for operands");
            }
        }
        smtm_Stmt(childAt(node, 4));
        smtm_Stmt(childAt(node, 6));
        break;
    case 6: // WHILE LP Exp RP Stmt
        childAt(node, 4)->inh = node->inh;
        smtm_Exp(childAt(node, 2));
        if (childAt(node, 2)->syn) {
            if (childAt(node, 2)->syn->type->kind != sINT) {
                serror(7, childAt(node, 2)->lineNum, "Type mismatched for operands");
            }
        }
        smtm_Stmt(childAt(node, 4));
        break;
    default:
        break;
    }
}


void smtm_StructSpecifier(Node *node){
    #ifdef SEM_DEBUG
    if(!node->inh)
        fprintf(stderr, "DUBUGGER(smtm_StructSpecifier): node->inh == NULL\n");
    else if(node->inh->type->kind != sSTRUCTURE)
        fprintf(stderr, "DUBUGGER(smtm_StructSpecifier): node->inh->type->kind != sSTRUCTURE\n");
    #endif
    //StructSpecifier ->STRUCT OptTag LC DefList RC
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
        fprintf(stderr, "smtm_StructSpecifier1...\n");
        #endif
        
        FieldList* p = (FieldList*)malloc(sizeof(FieldList));
        p->type = (sType*)malloc(sizeof(sType));
        p->type->kind = sSTRUCTURE;
        p->tail = NULL;
        node->child->next->inh = node->inh;
        node->child->next->next->next->inh = node->inh;
        node->child->next->next->next->structVarFlag = true;
        
        smtm_OptTag(node->child->next);
        smtm_DefList(node->child->next->next->next);
        
        //printf("return from DefList in StructSpecifier\n");

        if(!node->inh->type->u.structure)
            node->inh->type->u.structure = node->child->next->next->next->syn;
        else{
            FieldList* q = node->inh->type->u.structure;
            if(q->type->kind == sSTRUCTURE)
                q->type->u.structure = p;
            else 
                q->tail = p;
        }
        node->syn = node->inh;
        
    }
    //StructSpecifier -> STRUCT Tag
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_StructSpecifier2...\n");
        #endif
        node->inh->type->u.structure = NULL;
        node->child->next->inh = node->inh;
        smtm_Tag(node->child->next);
        node->syn = node->inh;
    }
    return ;
}

void smtm_OptTag(Node *node){
    #ifdef SEM_DEBUG
        if(!node->inh)
            fprintf(stderr, "DUBUGGER(smtm_OptTag): node->inh == NULL\n");
    #endif
    //OptTag -> ID
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_OptTag1...\n");
        #endif
        HashTable* strct = hash_find(node->child->val.strVal);
        if(strct){
            char s[512];
            sprintf(s, "Duplicated name \"%s\"", node->child->val.strVal);
            serror(16, node->lineNum, s);
        }
        else {
            HashTable* strct = (HashTable*)malloc(sizeof(HashTable));
            strct->next = NULL;
            strct->size = 0;
            strct->type = node->inh->type;
            strct->name = node->inh->name = node->child->val.strVal;
            hash_add(strct);
        }
    }
    return ;
}

void smtm_Tag(Node *node){
    //Tag -> ID
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Tag1...\n");
        #endif
        HashTable* id = hash_find(node->child->val.strVal);
        if(id){
            node->inh->name = id->name;
            node->inh->type = id->type;
        }
        else 
            node->inh->name = node->child->val.strVal;
    }
    return ;
}
/*
void smtm_VarDec(Node *node){
    //VarDec -> ID
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_VarDec1...\n");
        #endif
        HashTable* id = hash_find(node->child->val.strVal);
        if(id){
            char s[512];
            if(node->structVarFlag){
                sprintf(s, s, "Redefined field or Initing field in a struct\"%s\"", node->child->val.strVal);
                serror(15, node->lineNum, s);
                return;
            }
            else{
                sprintf(s, "Redefined variable \"%s\"", node->child->val.strVal);
                serror(3, node->lineNum, s);
                return;
            }
        }
        else {
            HashTable* i = (HashTable*)malloc(sizeof(HashTable));
            i->next = NULL;
            i->name = node->child->val.strVal;
            i->size = 0;
            
            FieldList* field = (FieldList*)malloc(sizeof(FieldList));
            field->tail = NULL;
            switch (node->inh->type->kind) {
            case sINT:
                i->size = 4;
                field->name = node->child->val.strVal;
                field->type = i->type = node->inh->type;
                node->syn = field;
                #ifdef SEM_DEBUG
                    printf("VarDec: Defining var %s as type INT\n", field->name);
                #endif
                break;
            case  sFLOAT:
                i->size = 4;
                field->name = node->child->val.strVal;
                field->type = i->type = node->inh->type;
                node->syn = field;
                #ifdef SEM_DEBUG
                    printf("VarDec: Defining var %s as type FLOAT\n", field->name);
                #endif
                break;           
            case sARRAY:
                i->size = 0;
                field->name = node->child->val.strVal;
                field->type = i->type = node->inh->type;
                node->syn = field;
                #ifdef SEM_DEBUG
                    printf("VarDec: Defining var %s as type ARRAY\n", field->name);
                #endif
                break;       
            case sSTRUCTURE:       
            case sSTRUCTVAR:

                if(node->inh->type->u.structure == NULL){
                    node->syn = NULL;
                    char s[512];
                    sprintf(s, "Undefined structure \"%s\"", node->inh->name);
                    serror(17, node->lineNum, s);
                    return;
                }

                field->name =node->child->val.strVal;
                field->type = (sType*)malloc(sizeof(sType));
                field->type->kind = sSTRUCTVAR;
                field->type->u.structVar = node->inh->type->u.structure;
                i->type = field->type;
                
                node->syn = field;
                #ifdef SEM_DEBUG
                    printf("VarDec: Defining var %s as type STRUTURE/STRUTUREVAR\n", field->name);
                #endif
                break;
            default:
                #ifdef SEM_DEBUG
                    fprintf(stderr, "DUBUGGER:smtm_VarDec1: unable to handle varType %d\n", node->inh->type->kind);
                #endif
                break;
            }      
            hash_add(i);
        }
    }
    //VarDec -> VarDec LB INT RB
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_VarDec2...\n");
        #endif
        node->child->structVarFlag |= node->structVarFlag;
        FieldList* field = (FieldList*)malloc(sizeof(FieldList));
        field->tail = NULL;
        field->type = (sType*)malloc(sizeof(sType));
        field->type->kind = sARRAY;
        field->type->u.array.size = node->child->next->next->val.intVal;
        if(node->inh->type->kind == sSTRUCTURE){
            field->type->u.array.elem = (sType*)malloc(sizeof(sType));
            field->type->u.array.elem->kind = sSTRUCTVAR;
            field->type->u.array.elem->u.structVar = node->inh->type->u.structure;
        }
        else 
            field->type->u.array.elem = node->inh->type;
        
        node->child->inh = field;
        smtm_VarDec(node->child);
        node->syn = node->child->syn;
    }
    return ;
}
*/
void smtm_VarDec(Node* node)
{
    // printf("VarDec\n");
    HashTable* res;
    switch (node->smtmType) {
    case 1: // ID
        printf("smtm_VarDec1\n");
        res = hash_find(node->child->val.strVal);
        if (!res) {
            HashTable* item = (HashTable*)malloc(sizeof(HashTable));
            item->name = node->child->val.strVal;
            item->next = NULL;
            item->size = 0;
            FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
            switch (node->inh->type->kind) {
            case sINT:
                item->type = node->inh->type;
                attr->name = node->child->val.strVal;
                attr->type = node->inh->type;
                attr->tail = NULL;
                node->syn = attr;
                item->size = 4;
                break;
            case sFLOAT:
                item->type = node->inh->type;
                attr->name = node->child->val.strVal;
                attr->type = node->inh->type;
                attr->tail = NULL;
                node->syn = attr;
                item->size = 4;
                break;
            case sARRAY:
                item->type = node->inh->type;
                attr->name = node->child->val.strVal;
                attr->type = node->inh->type;
                attr->tail = NULL;
                node->syn = attr;
                break;
            case sSTRUCTVAR:
            case sSTRUCTURE: {
                if (!node->inh->type->u.structure) {
                    char msg[512];
                    sprintf(msg, "Undefined structure \"%s\"", node->inh->name);
                    serror(17, node->lineNum, msg);
                    node->syn = NULL;
                    return;
                }
                sType* type = (sType*)malloc(sizeof(sType));
                type->kind = sSTRUCTVAR;
                type->u.structVar = node->inh->type->u.structure;
                attr->name = node->child->val.strVal;
                attr->type = type;
                attr->tail = NULL;
                item->type = type;
                node->syn = attr;
            } break;
            default:
                printf("name: %s, type: %d\n", node->child->val.strVal, node->inh->type->kind);
                exit(-1);
                break;
            }
            hash_add(item);
        } else {
            if (node->structVarFlag) {
                char msg[512];
                sprintf(msg, "Redefined field \"%s\"", node->child->val.strVal);
                serror(15, node->lineNum, msg);
            } else {
                char msg[512];
                sprintf(msg, "Redefined variable \"%s\"", node->child->val.strVal);
                serror(3, node->lineNum, msg);
            }
        }
        break;
    case 2: // VarDec LB INT RB
    {
        printf("smtm_VarDec2\n");
        if (node->structVarFlag)
            node->child->structVarFlag = 1;
        sType* type = (sType*)malloc(sizeof(sType));
        type->kind = sARRAY;
        //printNode(node, 0);
        printf("node == NULL = %d\n", node->child->next == NULL);
        type->u.array.size = childAt(node, 2)->val.intVal;
        if (node->inh->type->kind == sSTRUCTURE) {
            sType* p = (sType*)malloc(sizeof(sType));
            p->kind = sSTRUCTVAR;
            p->u.structVar = node->inh->type->u.structure;
            type->u.array.elem = p;
        } else {
            type->u.array.elem = node->inh->type;
        }
        FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
        attr->tail = NULL;
        attr->type = type;
        node->child->inh = attr;
        smtm_VarDec(node->child);
        node->syn = node->child->syn;
        break;
    }
    default:
        break;
    }
}


void smtm_DefList(Node *node){
    //DefList -> Def DefList
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_DefList1...\n");
        #endif
        if(node->structVarFlag)
            node->child->next->structVarFlag = node->child->structVarFlag = true;
        node->child->inh = node->child->next->inh = node->inh;
        smtm_Def(node->child);
        node->syn = node->child->syn;
        smtm_DefList(node->child->next);
        FieldList* p = node->syn;
        if(p) {
            while(p->tail) p = p->tail;
            p->tail = node->child->next->syn;
        }
    }
    //DefList -> null
    return ;
}

void smtm_Def(Node *node){
    //Def -> Specifier DecList SEMI
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Def1...\n");
        #endif
        if(node->structVarFlag)
            node->child->structVarFlag = node->child->next->structVarFlag = node->structVarFlag;
        node->child->inh = node->inh;
        smtm_Specifier(node->child);
        node->child->next->inh = node->child->syn;
        smtm_DecList(node->child->next);
        node->syn = node->child->next->syn;
    }
    return ;
}

void smtm_DecList(Node *node){
    if(node->inh->type->kind == sSTRUCTURE && node->inh->type->u.structure == NULL){
        char s[512];
        sprintf(s, "Undefined structure\"%s\"", node->inh->name);
        serror(17, node->lineNum, s);
        return;
    }

    //DecList -> Dec
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_DecList1...\n");
        #endif
        node->child->structVarFlag |= node->structVarFlag;
        node->child->inh = node->inh;
        smtm_Dec(node->child);
        node->syn = node->child->syn;
    }
    //DecList -> Dec COMMA DecList
    else if(node->smtmType == 2){
        node->child->structVarFlag |= node->structVarFlag;
        node->child->inh = node->inh;
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_DecList2...\n");
        #endif
        smtm_Dec(node->child);
        node->syn = node->child->syn;
        
        node->child->next->next->structVarFlag |= node->structVarFlag;
        node->child->next->next->inh = node->inh;
        smtm_DecList(node->child->next->next);
        FieldList* p = node->syn;
        while(p->tail) p = p->tail;
        p->tail = node->child->next->next->syn;
        /*
         if (node->structVarFlag)
            childAt(node, 2)->structVarFlag = 1;
        childAt(node, 2)->inh = node->inh;
        smtm_DecList(childAt(node, 2));
        FieldList* p = node->syn;
        while (p->tail) {
            p = p->tail;
        }
        p->tail = childAt(node, 2)->syn;*/
    }
    return ;
}

/*
void smtm_DecList(Node* node)
{
    if (node->structVarFlag)
        node->child->structVarFlag = 1;
    if (node->inh->type->kind == sSTRUCTURE && !node->inh->type->u.structure) {
        char msg[512];
        sprintf(msg, "Undefined structure \"%s\"", node->inh->name);
        serror(17, node->lineNum, msg);
        return;
    }
    node->child->inh = node->inh;
    smtm_Dec(node->child);
    node->syn = node->child->syn;
    switch (node->smtmType) {
    case 1: // Dec
        printf("smtm_DecList1\n");
        break;
    case 2: // Dec COMMA DecList
    {
        printf("smtm_DecList2\n");
        if (node->structVarFlag)
            childAt(node, 2)->structVarFlag = 1;
        childAt(node, 2)->inh = node->inh;
        smtm_DecList(childAt(node, 2));
        FieldList* p = node->syn;
        while (p->tail) {
            p = p->tail;
        }
        p->tail = childAt(node, 2)->syn;
    } break;
    default:
        break;
    }
}
*/
/*
void smtm_Dec(Node *node){
    //Dec -> VarDec
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Dec1...\n");
        #endif
        node->child->structVarFlag |= node->structVarFlag;
        node->child->inh = node->inh;
        smtm_VarDec(node->child);
        node->syn = node->child->syn;
    }
    //Dec -> VarDec ASSIGNOP Exp
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Dec2...\n");
        #endif
        node->child->structVarFlag |= node->structVarFlag;
        node->child->inh = node->inh;
        smtm_VarDec(node->child);
        node->syn = node->child->syn;

        if(node->structVarFlag) {
            char s[512];
            sprintf(s, "Redefined field or Initing field in a struct\"%s\"", node->child->syn->name);
            serror(15, node->child->lineNum, s);
            return;
        }
        
        smtm_Exp(node->child->next->next);

        if(node->child->syn && node->child->next->next->syn && 
            node->child->syn->type->kind != node->child->next->next->syn->type->kind)
            serror(5, node->child->lineNum, "Type mismatched for assignment");
    }
    return ;
}*/
void smtm_Dec(Node* node)
{
    // printf("Dec\n");
    if (node->structVarFlag)
        node->child->structVarFlag = 1;
    node->child->inh = node->inh;
    smtm_VarDec(node->child);
    node->syn = node->child->syn;
    switch (node->smtmType) {
    case 1: // VarDec
        printf("smtm_Dec1\n");
        break;
    case 2: // VarDec ASSIGNOP Exp
        printf("smtm_Dec2\n");
        if (node->structVarFlag) {
            char msg[512];
            sprintf(msg, "Try to init field \"%s\" in structure", node->child->syn->name);
            serror(15, node->child->lineNum, msg);
            return;
        }
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind != childAt(node, 2)->syn->type->kind) {
                serror(5, node->child->lineNum, "Type mismatched for assignment");
            }
        }
        break;
    default:
        break;
    }
}


void smtm_Exp(Node *node){

HashTable* res;
    //printf("Exp%d...\n", node->smtmType);
    switch (node->smtmType) {

    case 1: // Exp ASSIGNOP Exp
    {
        int id = node->child->smtmType;
        if (id < 14 || id > 16) {
            serror(6, node->child->lineNum, "The left-hand side of an assignment must be a variable");
            smtm_Exp(childAt(node, 2));
            return;
        } else {
            smtm_Exp(node->child);
        }
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind != childAt(node, 2)->syn->type->kind) {
                serror(5, node->child->lineNum, "Type mismatched for assignment");
            } else if (node->child->syn->type->kind == sSTRUCTVAR) {
                FieldList* p = node->child->syn->type->u.structVar;
                FieldList* q = childAt(node, 2)->syn->type->u.structVar;
                int res = structFieldCmp(p, q);
                if (!res) {
                    serror(5, node->child->lineNum, "Type mismatched for assignment");
                } else {
                    node->syn = node->child->syn;
                }
            } else if (node->child->syn->type->kind == sARRAY) {
                sType* p = node->child->syn->type;
                sType* q = childAt(node, 2)->syn->type;
                int res = arrayTypeCmp(p, q);
                if (!res) {
                    serror(5, node->child->lineNum, "Type mismatched for assignment");
                } else {
                    node->syn = node->child->syn;
                }
            } else {
                node->syn = node->child->syn;
            }
        } else {
            serror(5, node->child->lineNum, "Type mismatched for assignment");
        }
    } break;

    case 2: // Exp AND Exp
    
    case 3:
        smtm_Exp(node->child);
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind != sINT || childAt(node, 2)->syn->type->kind != sINT) {
                serror(7, node->child->lineNum, "Type mismatched for operands");
            } else {
                sType* type = (sType*)malloc(sizeof(sType));
                type->kind = sINT;
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->name = NULL;
                attr->type = type;
                attr->tail = NULL;
                node->syn = attr;
            }
        }
        break;
    
    
    
   
    case 4: // Exp RELOP Exp
        smtm_Exp(node->child);
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind == sINT && childAt(node, 2)->syn->type->kind == sINT || node->child->syn->type->kind == sFLOAT && childAt(node, 2)->syn->type->kind == sFLOAT) {
                sType* type = (sType*)malloc(sizeof(sType));
                type->kind = sINT;
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->name = NULL;
                attr->type = type;
                attr->tail = NULL;
                node->syn = attr;
            } else {
                serror(7, node->child->lineNum, "Type mismatched for operands");
            }
        }
        break;
    
    
    case 5: // Exp PLUS Exp
    
    case 6:
    
    case 7:
    
    case 8:
        smtm_Exp(node->child);
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind == sINT && childAt(node, 2)->syn->type->kind == sINT || node->child->syn->type->kind == sFLOAT && childAt(node, 2)->syn->type->kind == sFLOAT) {
                sType* type = (sType*)malloc(sizeof(sType));
                type->kind = node->child->syn->type->kind;
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->name = NULL;
                attr->type = type;
                attr->tail = NULL;
                node->syn = attr;
            } else {
                serror(7, node->child->lineNum, "Type mismatched for operands");
            }
        } else {
            serror(7, node->child->lineNum, "Type mismatched for operands");
        }
        break;
   
  
    case 9: // LP Exp RP
        smtm_Exp(childAt(node, 1));
        node->syn = childAt(node, 1)->syn;
        break;
    
    case 10: // MINUS Exp
        smtm_Exp(childAt(node, 1));
        if (childAt(node, 1)->syn) {
            if (childAt(node, 1)->syn->type->kind == sINT || childAt(node, 1)->syn->type->kind == sFLOAT) {
                node->syn = childAt(node, 1)->syn;
            } else {
                serror(7, node->lineNum, "Type mismatched for operands");
            }
        }
        break;
    
    case 11: // NOT Exp
        smtm_Exp(childAt(node, 1));
        if (childAt(node, 1)->syn) {
            if (childAt(node, 1)->syn->type->kind == sINT) {
                node->syn = childAt(node, 1)->syn;
            } else {
                serror(7, node->lineNum, "Type mismatched for operands");
            }
        }
        break;
    
    case 12: // ID LP Args RP
        res = hash_find(node->child->val.strVal);
        smtm_Args(childAt(node, 2));
        printf("return from Args in Exp12\n");
        if (!childAt(node, 2)->syn) {
            node->syn = NULL;
            return;
        }
        if (res) {
            if (res->type->kind != sFUNCTION) {
                char msg[512];
                sprintf(msg, "\"%s\" is not a function", res->name);
                serror(11, node->lineNum, msg);
            } else {
                int tmp = funcFieldCmp(res->type->u.function.argList, childAt(node, 2)->syn);
                printf("return from funcFieldCmp in Exp12\n");
                if (tmp) {
                    FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                    attr->tail = NULL;
                    attr->name = NULL;
                    attr->type = res->type->u.function.type;
                    node->syn = attr;
                } else {
                    char msg[512];
                    sprintf(msg, "Function \"%s\" is not applicable for arguments", res->name);
                    serror(9, childAt(node, 2)->lineNum, msg);
                }
            }
        } else {
            char msg[512];
            sprintf(msg, "Undefined function \"%s\"", node->child->val.strVal);
            serror(2, node->lineNum, msg);
            return;
        }
        break;
    
    case 13: // ID LP RP
        res = hash_find(node->child->val.strVal);
        if (res) {
            if (res->type->kind != sFUNCTION) {
                char msg[512];
                sprintf(msg, "\"%s\" is not a function", res->name);
                serror(11, node->lineNum, msg);
            } else if (res->type->u.function.argc != 0) {
                char msg[512];
                sprintf(msg, "Function \"%s\" is not applicable for arguments", res->name);
                serror(9, node->lineNum, msg);
            } else {
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->tail = NULL;
                attr->name = NULL;
                attr->type = res->type->u.function.type;
                node->syn = attr;
            }
        } else {
            char msg[512];
            sprintf(msg, "Undefined function \"%s\"", node->child->val.strVal);
            serror(2, node->lineNum, msg);
        }
        break;
    
    case 14: // Exp LB Exp RB
    {
        smtm_Exp(node->child);
        FieldList* attr = node->child->syn;
        if (!attr)
            return;
        if (attr->type->kind != sARRAY) {
            char msg[512];
            sprintf(msg, "\"%s\" is not a array", attr->name);
            serror(10, node->child->lineNum, msg);
        } else {
            FieldList* p = (FieldList*)malloc(sizeof(FieldList));
            p->tail = NULL;
            p->name = attr->name;
            p->type = attr->type->u.array.elem;
            node->syn = p;
        }
        smtm_Exp(childAt(node, 2));
        attr = childAt(node, 2)->syn;
        if (!attr)
            return;
        if (attr->type->kind != sINT) {
            char msg[512];
            sprintf(msg, "Index of array \"%s\" is not an integer", node->child->syn->name);
            serror(12, childAt(node, 2)->lineNum, msg);
        }
    
    } break;
    
    case 15: // Exp DOT ID
    {
        smtm_Exp(node->child);
        FieldList* attr = node->child->syn;
        if (!attr)
            return;
        if (attr->type->kind != sSTRUCTVAR) {
            serror(13, node->child->lineNum, "Illegal use of \".\"");
        } else {
            int flag = 0;
            for (FieldList* p = attr->type->u.structVar; p; p = p->tail) {
                if (!strcmp(childAt(node, 2)->val.strVal, p->name)) {
                    flag = 1;
                    node->syn = p;
                    break;
                }
            }
            if (!flag) {
                char msg[512];
                sprintf(msg, "Non-existent field \"%s\"", childAt(node, 2)->val.strVal);
                serror(14, node->child->lineNum, msg);
            }
        }
    
    } break;
  
    case 16: // ID
        res = hash_find(node->child->val.strVal);
        if (res) {
            FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
            attr->tail = NULL;
            attr->type = res->type;
            attr->name = res->name;
            node->syn = attr;
        } else {
            char msg[512];
            sprintf(msg, "Undefined Variable \"%s\"", node->child->val.strVal);
            serror(1, node->lineNum, msg);
        }
        break;
    
    case 17: // INT
    {
        sType* type = (sType*)malloc(sizeof(sType));
        type->kind = sINT;
        FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
        attr->tail = NULL;
        attr->type = type;
        attr->name = NULL;
        node->syn = attr;
    } break;
    case 18: // FLOAT
    {
        sType* type = (sType*)malloc(sizeof(sType));
        type->kind = sFLOAT;
        FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
        attr->tail = NULL;
        attr->type = type;
        attr->name = NULL;
        node->syn = attr;
    } break;
    default:
        break;
        
    }
/*
    //Exp -> Exp ASSIGNOP Exp
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp1...\n");
            HashTable* res = hash_find("Point");
            if(res){ printf("\nstruct Point: \n");printType(res->type, 0);}
        #endif
        if(node->child->smtmType == 14 || node->child->smtmType == 15 || node->child->smtmType == 16)
            smtm_Exp(node->child);
        else {
            serror(6, node->child->lineNum, "The left-hand side of an assignment must be a variable");
            smtm_Exp(node->child->next->next);
            return;
        }

        smtm_Exp(node->child->next->next);
        if(node->child->syn && node->child->next->next->syn){
            FieldList *syn1 = node->child->syn, *syn2 = node->child->next->next->syn;
            if(syn1->type->kind != syn2->type->kind){
                #ifdef SEM_DEBUG
                    printType(syn1->type, 0);
                    printf("assignment type mismatch: lefthand is %d, righthand is %d. ", syn1->type->kind, syn2->type->kind);
                #endif
                serror(5, node->child->lineNum, "Type mismatched for assignment");
            }
            else if(syn1->type->kind == sSTRUCTVAR){
                if(!structFieldCmp(syn1->type->u.structVar, syn2->type->u.structVar)){
                    #ifdef SEM_DEBUG
                        printf("struct type mismatch");
                    #endif
                    serror(5, node->child->lineNum, "Type mismatched for assignment");
                }
                else 
                    node->syn = node->child->syn;
            }
            else if(syn1->type->kind == sARRAY){
                if(!arrayTypeCmp(syn1->type, syn2->type))
                    serror(5, node->child->lineNum, "Type mismatched for assignment");
                else 
                    node->syn = node->child->syn;
            }
            else node->syn = node->child->syn;
        }
        else 
            serror(5, node->child->lineNum, "Type mismatched for assignment");
    }
    //Exp -> Exp AND Exp
    //          | Exp OR Exp
    else if(node->smtmType == 2 || node->smtmType == 3){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp%d...\n", node->smtmType);
        #endif
        smtm_Exp(node->child);
        smtm_Exp(node->child->next->next);
        FieldList *syn1 = node->child->syn, *syn2 = node->child->next->next->syn;
        if(syn1 && syn2){
            if(syn1->type->kind == sINT && syn2->type->kind == sINT){
                FieldList* field = (FieldList*)malloc(sizeof(FieldList));
                field->tail = NULL;
                field->name = NULL;
                field->type = (sType*)malloc(sizeof(sType));
                field->type->kind = sINT;
                node->syn = field;
            }
            else 
                serror(7, node->child->lineNum, "Type mismatched for operands");
        }
    }
    
    //Exp -> Exp RELOP Exp
    else if(node->smtmType == 4){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp4...\n");
        #endif
        smtm_Exp(node->child);
        smtm_Exp(node->child->next->next);
        FieldList *syn1 = node->child->syn, *syn2 = node->child->next->next->syn;
        if(syn1 && syn2){
            if(syn1->type->kind == syn2->type->kind &&(syn1->type->kind == sINT || syn1->type->kind == sFLOAT)){
                FieldList* field = (FieldList*)malloc(sizeof(FieldList));
                field->type = (sType*)malloc(sizeof(sType));
                field->tail = NULL;
                field->name = NULL;
                field->type->kind = sINT;
                node->syn = field;
            }
            else 
                serror(7, node->child->lineNum, "Type mismatched for operands");
        }
    }
    
    //Exp -> Exp PLUS Exp
    //          | Exp MINUS Exp
    //          | Exp STAR Exp
    //          | Exp DIV Ex
    else if(node->smtmType == 5 || node->smtmType == 6 || node->smtmType == 7
                || node->smtmType == 8){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp%d...\n", node->smtmType);
        #endif
        smtm_Exp(node->child);
        smtm_Exp(node->child->next->next);
        FieldList *syn1 = node->child->syn, *syn2 = node->child->next->next->syn;
        if(syn1 && syn2){
            if(syn1->type->kind == syn2->type->kind &&(syn1->type->kind == sINT || syn1->type->kind == sFLOAT)){
                FieldList* field = (FieldList*)malloc(sizeof(FieldList));
                field->type = (sType*)malloc(sizeof(sType));
                field->tail =NULL;
                field->name = NULL;
                field->type->kind = syn1->type->kind;
                node->syn = field;
            }
            else 
                serror(7, node->child->lineNum, "Type mismatched for operands");
        }
        else 
            serror(7, node->child->lineNum, "Type mismatched for operands");
    }
    
    //Exp -> LP Exp RP
    else if(node->smtmType == 9){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp9...\n");
        #endif
        smtm_Exp(node->child->next);
        node->syn = node->child->next->syn;
    }
    //Exp -> MINUS Exp
    else if(node->smtmType == 10){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp10...\n");
        #endif
        smtm_Exp(node->child->next);
        FieldList* syn1 = node->child->next->syn;
        if(syn1 && syn1->type->kind == sINT || syn1->type->kind == sFLOAT)
            node->syn = syn1;
        else 
            serror(7, node->child->lineNum, "Type mismatched for operands");
    }
    //Exp -> NOT Exp
    else if(node->smtmType == 11){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp11...\n");
        #endif
        smtm_Exp(node->child->next);
        FieldList* syn1 = node->child->next->syn;
        if(syn1 && syn1->type->kind == sINT)
            node->syn = syn1;
        else 
            serror(7, node->child->lineNum, "Type mismatched for operands");
    }
    //Exp -> ID LP Args RP
    else if(node->smtmType == 12){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp12...\n");
        #endif
        smtm_Args(node->child->next->next);
        if(node->child->next->next->syn == NULL){
            node->syn = NULL;
            return;
        }
        HashTable* funcField = hash_find(node->child->val.strVal);
        if(funcField){
            if(funcField->type->kind == sFUNCTION){
                if(funcFieldCmp(funcField->type->u.function.argList, node->child->next->next->syn)){
                    FieldList* field = (FieldList*)malloc(sizeof(FieldList));
                    field->type = funcField->type->u.function.type;
                    field->tail = NULL;
                    field->name = NULL;
                    node->syn = field;
                }
                else {
                    char s[512];
                    sprintf(s, "Function \"%s\" is not applicable for arguments", node->child->val.strVal);
                    serror(9, node->child->next->next->lineNum, s);
                }
            }
            else {
                char s[512];
                sprintf(s, "\"%s\" is not a function", node->child->val.strVal);
                serror(11, node->child->lineNum, s);
            }
        }
        else {
            char s[512];
            sprintf(s, "Undefined function \"%s\"", node->child->val.strVal);
            serror(2, node->lineNum, s);
        }
    }
    //Exp -> ID LP RP
    else if(node->smtmType == 13){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp13...\n");
        #endif
        HashTable* funcField = hash_find(node->child->val.strVal);
        if(funcField){
            if(funcField->type->kind == sFUNCTION){
                if(funcField->type->u.function.argc == 0){
                    FieldList* field = (FieldList*)malloc(sizeof(FieldList));
                    field->tail = NULL;
                    field->name = NULL;
                    field->type = funcField->type->u.function.type;
                    node->syn = field;
                }
                else {
                    char s[512];
                    sprintf(s, "Function \"%s\" is not applicable for arguments", node->child->val.strVal);
                    serror(9, node->child->next->next->lineNum, s);
                }
            }
            else {
                char s[512];
                sprintf(s, "\"%s\" is not a function", node->child->val.strVal);
                serror(11, node->child->lineNum, s);
            }
        }
        else {
            char s[512];
            sprintf(s, "Error type 2 at Line 4: Undefined function \"%s\"", node->child->val.strVal);
            serror(2, node->lineNum, s);
        }
    }
    //Exp -> Exp LB Exp RB
    else if(node->smtmType == 14){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp14...\n");
        #endif
        smtm_Exp(node->child);
        smtm_Exp(node->child->next->next);
        FieldList* syn1 = node->child->syn, *syn2 = node->child->next->next->syn;
        if(syn1 == NULL || syn2 == NULL) return;
        else if(syn1->type->kind == sARRAY){
            FieldList* field = (FieldList*)malloc(sizeof(FieldList));
            field->type = syn1->type->u.array.elem;
            field->name = syn1->name;
            field->tail = NULL;
            node->syn = field;
        }
        else {
            char s[512];
            sprintf(s, "\"%s\" is not an array", syn1->name);
            serror(10, node->child->lineNum, s);
        }

        if(syn2->type->kind == sINT){
            ;
        }
        else {
            char s[512];
            sprintf(s, "\"%d\" is not an integer", node->child->next->next->val.intVal);
            serror(12, node->child->next->next->lineNum, s);
        }
    }
    //Exp -> Exp DOT ID
    else if(node->smtmType == 15){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp15...\n");
        #endif
        smtm_Exp(node->child);
        FieldList* syn1 = node->child->syn;
        if(syn1 == NULL) return;
        else if(syn1->type->kind == sSTRUCTVAR) {
            #ifdef SEM_DEBUG
                printType(syn1->type, 0);
            #endif
            FieldList *p = syn1->type->u.structVar;
            bool validVarFlag = false;
            while(p){
                if(!strcmp(p->name, node->child->next->next->val.strVal)){
                    #ifdef SEM_DEBUG
                        printf("name matched: %s, kind = %d\n", p->name, p->type->kind);
                    #endif
                    validVarFlag = true;
                    node->syn = p;
                    break;
                }
                p = p->tail;
            }
            if(!validVarFlag){
                char s[512];
                sprintf(s, "Non-existent field\"%s\"", node->child->next->next->val.strVal);
                serror(14, node->child->lineNum, s);
            }
        }
        else 
            serror(13, node->child->lineNum, " Illegal use of \".\"");
    }
    //Exp -> ID
    else if(node->smtmType == 16){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp16...\n");
        #endif
        HashTable* id = hash_find(node->child->val.strVal);
        if(id){
            FieldList* field = (FieldList*)malloc(sizeof(FieldList));
            field->type = id->type;
            field->tail = NULL;
            field->name = id->name;
            node->syn = field;
        }
        else {
            char s[512];
            sprintf(s, "Undefined variable \"%s\"", node->child->val.strVal);
            serror(1, node->lineNum, s);
        }
    }
    //Exp -> INT
    else if(node->smtmType == 17){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp17...\n");
        #endif
        FieldList* field = (FieldList*)malloc(sizeof(FieldList));
        field->tail = NULL;
        field->name = NULL;
        field->type = (sType*)malloc(sizeof(sType));
        field->type->kind = sINT;
        node->syn = field;
    }
    //Exp -> FLOAT
    else if(node->smtmType == 18){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Exp18...\n");
        #endif
        FieldList* field = (FieldList*)malloc(sizeof(FieldList));
        field->tail = NULL;
        field->name = NULL;
        field->type = (sType*)malloc(sizeof(sType));
        field->type->kind = sFLOAT;
        node->syn = field;
    }
    */
    return ;
}

/*
void smtm_Exp(Node* node)
{
    // printf("Exp\n");
    HashTable* res;
    switch (node->smtmType) {
    case 1: // Exp ASSIGNOP Exp
    {
        int id = node->child->smtmType;
        if (id < 14 || id > 16) {
            serror(6, node->child->lineNum, "The left-hand side of an assignment must be a variable");
            smtm_Exp(childAt(node, 2));
            return;
        } else {
            smtm_Exp(node->child);
        }
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind != childAt(node, 2)->syn->type->kind) {
                serror(5, node->child->lineNum, "Type mismatched for assignment");
            } else if (node->child->syn->type->kind == sSTRUCTVAR) {
                FieldList* p = node->child->syn->type->u.structVar;
                FieldList* q = childAt(node, 2)->syn->type->u.structVar;
                int res = structFieldCmp(p, q);
                if (!res) {
                    serror(5, node->child->lineNum, "Type mismatched for assignment");
                } else {
                    node->syn = node->child->syn;
                }
            } else if (node->child->syn->type->kind == sARRAY) {
                sType* p = node->child->syn->type;
                sType* q = childAt(node, 2)->syn->type;
                int res = arrayTypeCmp(p, q);
                if (!res) {
                    serror(5, node->child->lineNum, "Type mismatched for assignment");
                } else {
                    node->syn = node->child->syn;
                }
            } else {
                node->syn = node->child->syn;
            }
        } else {
            serror(5, node->child->lineNum, "Type mismatched for assignment");
        }
    } break;
    case 2: // Exp AND Exp
    case 3:
        smtm_Exp(node->child);
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind != sINT || childAt(node, 2)->syn->type->kind != sINT) {
                serror(7, node->child->lineNum, "Type mismatched for operands");
            } else {
                sType* type = (sType*)malloc(sizeof(sType));
                type->kind = sINT;
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->name = NULL;
                attr->type = type;
                attr->tail = NULL;
                node->syn = attr;
            }
        }
        break;
    case 4: // Exp RELOP Exp
        smtm_Exp(node->child);
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind == sINT && childAt(node, 2)->syn->type->kind == sINT || node->child->syn->type->kind == sFLOAT && childAt(node, 2)->syn->type->kind == sFLOAT) {
                sType* type = (sType*)malloc(sizeof(sType));
                type->kind = sINT;
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->name = NULL;
                attr->type = type;
                attr->tail = NULL;
                node->syn = attr;
            } else {
                serror(7, node->child->lineNum, "Type mismatched for operands");
            }
        }
        break;
    case 5: // Exp PLUS Exp
    case 6:
    case 7:
    case 8:
        smtm_Exp(node->child);
        smtm_Exp(childAt(node, 2));
        if (node->child->syn && childAt(node, 2)->syn) {
            if (node->child->syn->type->kind == sINT && childAt(node, 2)->syn->type->kind == sINT || node->child->syn->type->kind == sFLOAT && childAt(node, 2)->syn->type->kind == sFLOAT) {
                sType* type = (sType*)malloc(sizeof(sType));
                type->kind = node->child->syn->type->kind;
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->name = NULL;
                attr->type = type;
                attr->tail = NULL;
                node->syn = attr;
            } else {
                serror(7, node->child->lineNum, "Type mismatched for operands");
            }
        } else {
            serror(7, node->child->lineNum, "Type mismatched for operands");
        }
        break;
    case 9: // LP Exp RP
        smtm_Exp(childAt(node, 1));
        node->syn = childAt(node, 1)->syn;
        break;
    case 10: // MINUS Exp
        smtm_Exp(childAt(node, 1));
        if (childAt(node, 1)->syn) {
            if (childAt(node, 1)->syn->type->kind == sINT || childAt(node, 1)->syn->type->kind == sFLOAT) {
                node->syn = childAt(node, 1)->syn;
            } else {
                serror(7, node->lineNum, "Type mismatched for operands");
            }
        }
        break;
    case 11: // NOT Exp
        smtm_Exp(childAt(node, 1));
        if (childAt(node, 1)->syn) {
            if (childAt(node, 1)->syn->type->kind == sINT) {
                node->syn = childAt(node, 1)->syn;
            } else {
                serror(7, node->lineNum, "Type mismatched for operands");
            }
        }
        break;
    case 12: // ID LP Args RP
        res = hash_find(node->child->val.strVal);
        smtm_Args(childAt(node, 2));
        if (!childAt(node, 2)->syn) {
            node->syn = NULL;
            return;
        }
        if (res) {
            if (res->type->kind != sFUNCTION) {
                char msg[512];
                sprintf(msg, "\"%s\" is not a function", res->name);
                serror(11, node->lineNum, msg);
            } else {
                int tmp = funcFieldCmp(res->type->u.function.argList, childAt(node, 2)->syn);
                if (tmp) {
                    FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                    attr->tail = NULL;
                    attr->name = NULL;
                    attr->type = res->type->u.function.type;
                    node->syn = attr;
                } else {
                    char msg[512];
                    sprintf(msg, "Function \"%s\" is not applicable for arguments", res->name);
                    serror(9, childAt(node, 2)->lineNum, msg);
                }
            }
        } else {
            char msg[512];
            sprintf(msg, "Undefined function \"%s\"", node->child->val.strVal);
            serror(2, node->lineNum, msg);
            return;
        }
        break;
    case 13: // ID LP RP
        res = hash_find(node->child->val.strVal);
        if (res) {
            if (res->type->kind != sFUNCTION) {
                char msg[512];
                sprintf(msg, "\"%s\" is not a function", res->name);
                serror(11, node->lineNum, msg);
            } else if (res->type->u.function.argc != 0) {
                char msg[512];
                sprintf(msg, "Function \"%s\" is not applicable for arguments", res->name);
                serror(9, node->lineNum, msg);
            } else {
                FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
                attr->tail = NULL;
                attr->name = NULL;
                attr->type = res->type->u.function.type;
                node->syn = attr;
            }
        } else {
            char msg[512];
            sprintf(msg, "Undefined function \"%s\"", node->child->val.strVal);
            serror(2, node->lineNum, msg);
        }
        break;
    case 14: // Exp LB Exp RB
    {
        smtm_Exp(node->child);
        FieldList* attr = node->child->syn;
        if (!attr)
            return;
        if (attr->type->kind != sARRAY) {
            char msg[512];
            sprintf(msg, "\"%s\" is not a array", attr->name);
            serror(10, node->child->lineNum, msg);
        } else {
            FieldList* p = (FieldList*)malloc(sizeof(FieldList));
            p->tail = NULL;
            p->name = attr->name;
            p->type = attr->type->u.array.elem;
            node->syn = p;
        }
        smtm_Exp(childAt(node, 2));
        attr = childAt(node, 2)->syn;
        if (!attr)
            return;
        if (attr->type->kind != sINT) {
            char msg[512];
            sprintf(msg, "Index of array \"%s\" is not an integer", node->child->syn->name);
            serror(12, childAt(node, 2)->lineNum, msg);
        }
    } break;
    
    case 15: // Exp DOT ID
    {
        smtm_Exp(node->child);
        FieldList* attr = node->child->syn;
        if (!attr)
            return;
        if (attr->type->kind != sSTRUCTVAR) {
            serror(13, node->child->lineNum, "Illegal use of \".\"");
        } else {
            int flag = 0;
            for (FieldList* p = attr->type->u.structVar; p; p = p->tail) {
                if (!strcmp(childAt(node, 2)->val.strVal, p->name)) {
                    flag = 1;
                    node->syn = p;
                    break;
                }
            }
            if (!flag) {
                char msg[512];
                sprintf(msg, "Non-existent field \"%s\"", childAt(node, 2)->val.strVal);
                serror(14, node->child->lineNum, msg);
            }
        }
    } break;
    
    case 16: // ID
        res = hash_find(node->child->val.strVal);
        if (res) {
            FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
            attr->tail = NULL;
            attr->type = res->type;
            attr->name = res->name;
            node->syn = attr;
        } else {
            char msg[512];
            sprintf(msg, "Undefined Variable \"%s\"", node->child->val.strVal);
            serror(1, node->lineNum, msg);
        }
        break;
    case 17: // INT
    {
        sType* type = (sType*)malloc(sizeof(sType));
        type->kind = sINT;
        FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
        attr->tail = NULL;
        attr->type = type;
        attr->name = NULL;
        node->syn = attr;
    } break;
    case 18: // FLOAT
    {
        sType* type = (sType*)malloc(sizeof(sType));
        type->kind = sFLOAT;
        FieldList* attr = (FieldList*)malloc(sizeof(FieldList));
        attr->tail = NULL;
        attr->type = type;
        attr->name = NULL;
        node->syn = attr;
    } break;
    default:
        break;
    }
}*/

void smtm_Args(Node *node){
    //Args -> Exp...
    smtm_Exp(node->child);
    FieldList* syn1 = node->child->syn;
    if(syn1){
        node->syn = (FieldList*)malloc(sizeof(FieldList));
        node->syn->tail = NULL;
        node->syn->name = syn1->name;
        node->syn->type = syn1->type;
    }
    else 
        node->syn = NULL;
    //Args -> Exp COMMA Args
    if(node->smtmType == 1){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Args1...\n");
        #endif
        smtm_Args(node->child->next->next);
        if(node->syn)
            node->syn->tail = node->child->next->next->syn;
    }
    //Args -> Exp
    else if(node->smtmType == 2){
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Args2...\n");
        #endif
        ;
    }
    return ;
}
/*
void smtm_Args(Node* node)
{
    // printf("Args\n");
    smtm_Exp(node->child);
    if (node->child->syn) {
        node->syn = (FieldList*)malloc(sizeof(FieldList));
        node->syn->name = node->child->syn->name;
        node->syn->type = node->child->syn->type;
        node->syn->tail = NULL;
    } else {
        node->syn = NULL;
    }
    switch (node->lineNum) {
    case 1: // Exp COMMA Args
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Args1...\n");
        #endif
        smtm_Args(childAt(node, 2));
        if (node->syn)
            node->syn->tail = childAt(node, 2)->syn;
        break;
    case 2: // Exp
        #ifdef SEM_DEBUG
            fprintf(stderr, "smtm_Args2...\n");
        #endif
        break;
    default:
        break;
    }
}*/
/*
void smtm_Args(Node* node)
{
    // printf("Args\n");
    smtm_Exp(node->child);
    if (node->child->syn) {
        node->syn = (FieldList*)malloc(sizeof(FieldList));
        node->syn->name = node->child->syn->name;
        node->syn->type = node->child->syn->type;
        node->syn->tail = NULL;
    } else {
        node->syn = NULL;
    }
    switch (node->lineNum) {
    case 1: // Exp COMMA Args
        smtm_Args(childAt(node, 2));
        if (node->syn)
            node->syn->tail = childAt(node, 2)->syn;
        break;
    case 2: // Exp
        break;
    default:
        break;
    }
}
*/

bool structFieldCmp(FieldList* s1, FieldList* s2){
    bool flag = false; //bool flag = false;
    while(s1 && s2) { //while (s1 && s2) {
        if(s1 == s2) //if (s1 == s2)
            return true;  //return true;
        else if(s1->type->kind != s2->type->kind) { //else if (s1->type->kind != s2->type->kind) {
            return false; //return false;
        }else if(s1->type->kind == sSTRUCTVAR || s1->type->kind == sSTRUCTURE){
        //} else if (s1->type->kind == sSTRUCTVAR || s1->type->kind == sSTRUCTURE) {
            flag = structFieldCmp(s1->type->u.structVar, s2->type->u.structVar);
            //flag = structFieldCmp(s1->type->u.structVar, s2->type->u.structVar);
            if(!flag)//if (!flag)
                return false; //return false;
        }
        else if(s1->type->kind == sARRAY){ //} else if (s1->type->kind == sARRAY) {
            flag = arrayTypeCmp(s1->type, s2->type); //flag = arrayTypeCmp(s1->type, s2->type);
            if(!flag) // if (!flag)
                return false; //return false;
        } //} else {
        else {flag = true;} //flag = true;}
        s1 = s1->tail;  //s1 = s1->tail;
        s2 = s2->tail; //s2 = s2->tail;
    } //}
    if(s1 || s2) //if (s1 || s2)
        flag = false; //flag = false;
    return flag; //return flag;
}
/*
bool structFieldCmp(FieldList* s1, FieldList* s2)
{
    bool flag = false;
    while (s1 && s2) {
        if (s1 == s2)
            return true;
        else if (s1->type->kind != s2->type->kind) {
            return false;
        } else if (s1->type->kind == sSTRUCTVAR || s1->type->kind == sSTRUCTURE) {
            flag = structFieldCmp(s1->type->u.structVar, s2->type->u.structVar);
            if (!flag)
                return false;
        } else if (s1->type->kind == sARRAY) {
            flag = arrayTypeCmp(s1->type, s2->type);
            if (!flag)
                return false;
        } else {
            flag = true;
        }
        s1 = s1->tail;
        s2 = s2->tail;
    }
    if (s1 || s2)
        flag = false;
    return flag;
}
*/
/*
bool funcFieldCmp(FieldList* a, FieldList* b){
    while(a != NULL && b != NULL) {
        if(a->type->kind != b->type->kind) return false;
        if(a->type->kind == sSTRUCTVAR)
            if(!structFieldCmp(a->type->u.structVar, b->type->u.structVar)) return false;
        else if(a->type->kind == sARRAY)
            if(!arrayTypeCmp(a->type, b->type)) return false;
        else if(a == b) return true;
        a = a->tail, b = b->tail;
    }
    if(a == NULL && b == NULL)
        return true;
    return false;
}

*/
bool funcFieldCmp(FieldList* arg1, FieldList* arg2)
{
    int res;
    while (arg1 && arg2) {
        if (arg1 == arg2)
            return 1;
        else if (arg1->type->kind != arg2->type->kind) {
            return 0;
        } else if (arg1->type->kind == sSTRUCTVAR) {
            res = structFieldCmp(arg1->type->u.structVar, arg2->type->u.structVar);
            if (!res)
                return 0;
        } else if (arg1->type->kind == sARRAY) {
            res = arrayTypeCmp(arg1->type, arg2->type);
            if (!res)
                return 0;
        } else
            res = 1;
        arg1 = arg1->tail;
        arg2 = arg2->tail;
    }
    if (arg1 || arg2)
        res = 0;
    return res;
}

/*
bool arrayTypeCmp(sType*a, sType* b){
    while(a != NULL && b != NULL) {
        if(a->u.array.elem->kind != b->u.array.elem->kind) return false;
        if(a->u.array.elem->kind = sSTRUCTURE || a->u.array.elem->kind == sSTRUCTVAR)
            if(!structFieldCmp(a->u.array.elem->u.structure, b->u.array.elem->u.structure)) return false;
            else return true;
        else if(a->u.array.elem->kind != sARRAY)
            return true;
        else if(a == b) return true;
        a = a->u.array.elem, b = b->u.array.elem;
    }
    if(a == NULL && b == NULL)
        return true;
    return false;
}
*/
bool arrayTypeCmp(sType* t1, sType* t2)
{
    int res;
    while (t1 && t2) {
        if (t1 == t2)
            return 1;
        else if (t1->u.array.elem->kind != t2->u.array.elem->kind) {
            return 0;
        } else if (t1->u.array.elem->kind == sSTRUCTURE || t1->u.array.elem->kind == sSTRUCTVAR) {
            res = structFieldCmp(t1->u.array.elem->u.structVar, t2->u.array.elem->u.structVar);
            if (!res)
                return 0;
            else
                return 1;
        } else if (t1->u.array.elem->kind != sARRAY) {
            return 1;
        }
        t1 = t1->u.array.elem;
        t2 = t2->u.array.elem;
    }
    if (t1 || t2)
        res = 0;
    return res;
}

void printType(sType* type, int depth)
{
    for (int i = 0; i < depth; ++i)
        printf("  ");
    printf("type: ");
    switch (type->kind) {
    case sINT:
        printf("int\n");
        break;
    case sFLOAT:
        printf("float\n");
        break;
    case sARRAY:
        printf("array, size: %d\n", type->u.array.size);
        printType(type->u.array.elem, depth + 1);
        break;
    case sSTRUCTURE: {
        printf("structure\n");
        FieldList* p = type->u.structure;
        while (p) {
            for (int i = 0; i < depth + 1; ++i)
                printf("  ");
            printf("name: %s\n", p->name);
            printType(p->type, depth + 1);
            p = p->tail;
        }
        break;
    }
    case sSTRUCTVAR: {
        printf("structvar\n");
        FieldList* p = type->u.structVar;
        while (p) {
            for (int i = 0; i < depth + 1; ++i)
                printf("  ");
            printf("name: %s\n", p->name);
            printType(p->type, depth + 1);
            p = p->tail;
        }
    } break;
    case sFUNCTION: {
        printf("function\n");
        sType* ret = type->u.function.type;
        for (int i = 0; i < depth + 1; ++i)
            printf("  ");
        printf("return:\n");
        printType(ret, depth + 2);
        for (int i = 0; i < depth + 1; ++i)
            printf("  ");
        printf("argc: %d\n", type->u.function.argc);
        for (int i = 0; i < depth + 1; ++i)
            printf("  ");
        printf("args:\n");
        FieldList* p = type->u.function.argList;
        while (p) {
            for (int i = 0; i < depth + 2; ++i)
                printf("  ");
            printf("name: %s\n", p->name);
            printType(p->type, depth + 2);
            p = p->tail;
        }
    } break;
    default:
        // printf("%d\n", type->kind);
        break;
    }
}

Node *childAt(Node *node, int index)
{
    Node *p = node->child;
    for (int i = 0; i < index; ++i)
    {
        if (!p)
        {
            printf("Index of child out of range!\n");
            exit(-1);
        }
        p = p->next;
    }
    return p;
}