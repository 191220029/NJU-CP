# NJU_Compiler2021

NJUCS编译原理实验

## 运行环境

- Ubuntu 16.04 x64
- gcc 5.4.0
- flex 2.6.0
- bison 3.0.4